import streamlit as st
from st_card_component import card_component
import pandas as pd


st.set_page_config(layout="wide")


@st.cache_data
def get_products():
    df = pd.read_csv("products.csv")
    return df


quantities = {}

steps = {
    "kg": [0, 0.5] + list(range(1, 11, 1)),
    "unité": list(range(0, 11, 1)),
    "gr": list(range(0, 1100, 100)) + [1500, 2000],
    "botte": list(range(0, 11, 1)),
    "pièce": list(range(0, 11, 1)),
    "paquet": list(range(0, 11, 1)),
    "portion": list(range(0, 11, 1)),
}
product_list = get_products()
published_products = product_list.loc[product_list["Published"] == 1, :].reset_index(
    drop=True
)

published_products["Steps"] = published_products["Mesure"].map(steps)

for i, each in published_products.iterrows():
    id = each["ID"]
    name = each["Name"]
    description = "" if pd.isnull(each["Description"]) else each["Description"]
    category = each["Categories"]
    price = each["Regular price"]
    image_url = each["Images"]
    decorator = each["Mesure"]
    steps = each["Steps"]

    quantities[id] = card_component(
        name=name,
        description=description,
        category=category,
        price=price,
        image_url=image_url,
        decorator=decorator,
        steps=steps,
        key=i,
    )

quantities_df = pd.DataFrame(
    quantities.values(), index=quantities.keys(), columns=["Quantité"]
)
st.dataframe(quantities_df)
