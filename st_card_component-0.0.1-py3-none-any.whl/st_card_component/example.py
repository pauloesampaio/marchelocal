import streamlit as st
from st_card_component import card_component
import pandas as pd
import os


def make_grid(cols, rows):
    grid = [0] * cols
    for i in range(cols):
        with st.container():
            grid[i] = st.columns(rows)
    return grid


st.set_page_config(layout="wide")
print(os.getcwd())


@st.cache_data
def get_products():
    df = pd.read_csv("products.csv")
    return df


quantities = {}

product_list = get_products()
published_products = product_list.loc[product_list["Published"] == 1, :].reset_index(
    drop=True
)

for i, each in published_products.iterrows():
    id = each["ID"]
    name = each["Name"]
    description = "" if pd.isnull(each["Description"]) else each["Description"]
    category = each["Categories"]
    price = each["Regular price"]
    image_url = each["Images"]
    quantities[id] = card_component(
        name=name,
        description=description,
        category=category,
        price=price,
        image_url=image_url,
        key=i,
    )

quantities_df = pd.DataFrame(
    quantities.values(), index=quantities.keys(), columns=["Quantité"]
)
st.dataframe(quantities_df)
